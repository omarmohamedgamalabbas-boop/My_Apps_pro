# My Apps release rules
